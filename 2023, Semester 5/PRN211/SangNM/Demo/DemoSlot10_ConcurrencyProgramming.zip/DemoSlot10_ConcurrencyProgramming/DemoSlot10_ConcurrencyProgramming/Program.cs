﻿using System;

namespace DemoSlot10_ConcurrencyProgramming
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
